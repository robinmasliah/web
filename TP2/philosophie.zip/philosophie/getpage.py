import setpath
from bs4 import BeautifulSoup
from json import loads
from urllib.request import urlopen
from urllib.parse import urlencode, unquote, urldefrag
import re
# Pour rendre le travail
# moodle.r2.enst.fr/moodle/mod/assign/view.php?id=417


def getJSON(page):
    params = urlencode({
      'format' : 'json',
      'action' : 'parse', 
      'prop' : 'text',
      'redirects' : 'true',
      'page': page})
    API = "https://fr.wikipedia.org/w/api.php"
    response = urlopen(API + "?" + params)
    return response.read().decode('utf-8')


def getRawPage(page):
    parsed = loads(getJSON(page))
    try:
        title = parsed['parse']['title']
        content = parsed['parse']['text']['*']
        return title, content
    except KeyError:
        # La page demandée n'existe pas
        return None, None


def getPage(page):
    
    tab_links = []
  
    title, content = getRawPage(page)
    soup = BeautifulSoup(content, 'html.parser')
    var = soup.find('div')
    cont_var = var.find_all('p', recursive=True)
    
    for p in cont_var:
        links = p.find_all('a', href=True)
        for link in links:
            link = link.get('href')
            if len(tab_links) < 10 and re.search('(?<=:)\w+', link) is None:
                link = link.replace('/wiki/', '')
                link = unquote(urldefrag(link)[0])
                link = link.replace("_"," ")
                if getRawPage(link) != (None, None):    
                    if link not in tab_links:
                        tab_links.append(link)
            else:
                break

    return title, tab_links
    

if __name__ == '__main__':

    print('test')
    # Voici des idées pour tester vos fonctions :
    #print(getJSON("Utilisateur:A3nm/INF344"))
    # print(getRawPage("Utilisateur:A3nm/INF344"))
    # print(getRawPage("Histoire"))

