#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Ne pas se soucier de ces imports
import setpath
from flask import Flask, render_template, session, request, redirect, flash, url_for
from getpage import getPage

app = Flask(__name__)

global cache
cache = {}

app.secret_key = "TODO: mettre une valeur secrète ici"

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/new-game', methods=['POST'])
def newgame():
    session['article'] = request.form['start']
    session['score'] = 0
    return redirect('/game')

@app.route('/game', methods=['GET'])
def game(title=None, links=None):
    if session['article'] in cache.keys():
        t, h = cache[session['article']]
    else:
        t, h = getPage(session['article'])
    
    cache[session['article']] = t, h
    
    return render_template('game.html', title=t, links=h)

@app.route('/move', methods=['POST'])
def move():
    if request.form['destination'] == 'Philosophie':
        session['article'] = request.form['destination']
        session['score'] = session['score'] + 1
        flash('Bien joué !!!')
        return redirect('/game')
    else:
        session['article'] = request.form['destination']
        session['score'] = session['score'] + 1
        flash('continue')
    return redirect('/game')


# Si vous définissez de nouvelles routes, faites-le ici

if __name__ == '__main__':
    app.run(debug=True)

